  <div id="topmenu">
    <ul>
	<?php
	if(isset($_SESSION['aktivni_korisnik'])){
	?>
      <li><a href="kosarica.php" id="topmenu1" accesskey="1">Košarica <?php if(isset($_SESSION["proizvodi"])) { echo "(".count($_SESSION["proizvodi"]).")"; } ?></a></li>
	<?php
	}
	?>	  
      <li><a href="popisskripti.php" id="topmenu3" accesskey="3">Popis skripti</a></li>
    </ul>
  </div>