<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
      <?php	
	
			if(isset($_GET["naruciproizvod"])){
				$idproizvod=$_GET["naruciproizvod"];
				
				$sql="select pr.proizvod_id, pr.naziv, pr.cijena, kt.kategorija_id, kt.naziv from proizvod pr inner join kategorija kt on pr.kategorija_id = kt.kategorija_id 
							where pr.proizvod_id = ".$idproizvod;
							$izvrsi=izvrsiBP($sql);							
							list($proizvodid,$naziv,$cijena,$kategorijaid,$kategorijanaziv)=mysqli_fetch_row($izvrsi);
					?>
				<h3>Narudžba proizvoda:</h3>
				<table id="htmlform">
				<form name="narudzbaproizvod" id="narudzbaproizvod" action="narudzba.php" method="POST" onsubmit="return ProvjeriNarudzbu(this)">
				<input type="hidden" name="proizvodid" id="proizvodid" value="<?php echo $proizvodid; ?>">
				<input type="hidden" name="kategorijaid" id="kategorijaid" value="<?php echo $kategorijaid; ?>">
				<input type="hidden" name="cijena" id="cijena" value="<?php echo $cijena; ?>">
				<tr>
				<td>
				<label for="Kategorija"><strong>Kategorija:</strong></label>
				</td>
				<td>
				<?php echo $kategorijanaziv; ?>
				</td>
				</tr>
				<tr>
				<td>
				<label for="Naziv"><strong>Naziv:</strong></label>
				</td>
				<td>
				<?php echo $naziv; ?>
				</td>
				</tr>
				<tr>
				<td>
				<label for="Cijena"><strong>Cijena:</strong></label>
				</td>
				<td>
				<?php echo $cijena; ?>
				</td>
				</tr>				
				<tr>
				<td>
				<label for="kolicina"><strong>Količina:</strong></label>
				</td>
				<td>
				<input type="text" name="kolicina" id="kolicina" value="">
				</td>
				</tr>	
			<tr>
			<td colspan="2"><input type="submit" name="NaruciProizvod" id="NaruciProizvod" value="Naruči proizvod">
			</td>
			</tr>
			</table>
			</form>
	
	<?php	
				
			}
			
			if(isset($_POST["NaruciProizvod"])){
				
				$proizvodid=$_POST["proizvodid"];
				$kategorijaid=$_POST["kategorijaid"];
				$kolicina=$_POST["kolicina"];
				$cijena=$_POST["cijena"];
				
				if(($kolicina*$cijena)<=PreostaloLimitaUKategoriji($kategorijaid)){					
					$blokirana=0;
				}
				else
				{
					$blokirana=1;
				}
				
				$sql="insert into narudzba (korisnik_id,proizvod_id,kolicina,blokirana,prihvacena,datum_kreiranja) values ('$aktivni_korisnik_id','$proizvodid','$kolicina','$blokirana',0,now())";
				$izvrsi=izvrsiBP($sql);
				unset($_SESSION["proizvodi"][$proizvodid]);
				header("Location: korisniknarudzbe.php");
			}
			
			if(isset($_GET["prihvatinarudzbu"])){
				$narudzbaid=$_GET["prihvatinarudzbu"];
				$str=$_GET["str"];
				$sql="update narudzba set prihvacena = 1 where narudzba_id = ".$narudzbaid;
				$izvrsi=izvrsiBP($sql);
				header("Location: moderatornarudzbe.php?str=$str");
			}
			
			if(isset($_GET["odblokirajnarudzbu"])){
				$narudzbaid=$_GET["odblokirajnarudzbu"];
				$str=$_GET["str"];
				$sql="update narudzba set blokirana = 0 where narudzba_id = ".$narudzbaid;
				$izvrsi=izvrsiBP($sql);
				header("Location: adminnarudzbe.php?str=$str");
			}
			
			
			
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>