<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	<h3>Popis mojih narudžbi</h3>
      <?php	
	
		$sql = "SELECT
nar.narudzba_id,
pr.proizvod_id,
pr.naziv,
kt.naziv,
nar.kolicina,
pr.cijena,
(nar.kolicina*pr.cijena) AS 'Ukupno',
pr.slika,
nar.blokirana,
nar.prihvacena,
nar.datum_kreiranja
FROM narudzba nar
INNER JOIN proizvod pr
ON nar.proizvod_id = pr.proizvod_id
INNER JOIN kategorija kt
on kt.kategorija_id = pr.kategorija_id 
WHERE nar.korisnik_id = ".$aktivni_korisnik_id." order by nar.datum_kreiranja desc";		
	$izvrsi=izvrsiBP($sql);	 
	$broj_redaka = mysqli_num_rows($izvrsi);
	$broj_str = ceil($broj_redaka / $vel_str);	
	$sql .= " limit ".$vel_str;		
	
	if (isset($_GET['str'])){
		$sql = $sql . " OFFSET " . (($_GET['str'] - 1) * $vel_str);
		$aktivna = $_GET['str'];
	} else {
		$aktivna = 1;
	}
	
	$izvrsi=izvrsiBP($sql);
	$kol=8;
	echo "<table id = \"dataview\">";
	echo "<thead>";
	echo "<tr>";
	echo "<th>ID narudžbe</th>";
	echo "<th>Proizvod</th>";
	echo "<th>Kategorija</th>";
	echo "<th>Količina</th>";
	echo "<th>Cijena</th>";
	echo "<th>Datum kreiranja</th>";
	echo "<th>Blokirana</th>";
	echo "<th>Prihvaćena</th>";
	echo "</tr>";
	echo "</thead>";
	
	echo "<tbody>";
	if(mysqli_num_rows($izvrsi)>0){
		while(list($narudzbaid,$proizvodid, $nazivproizvod, $nazivkategorija, $kolicina,$cijena,$ukupno,$slika,$blokirana,$prihvacena,$datumkreiranja)=mysqli_fetch_row($izvrsi)){
			$datumkreiranja=date("d.m.Y H:i:s",strtotime($datumkreiranja));
			if($blokirana==1){
				$blokirana="da";
			}
			else
			{
				$blokirana="ne";
			}
			
			if($prihvacena==1){
				$prihvacena="da";
			}
			else
			{
				$prihvacena="ne";
			}
			echo "<tr>";
			echo "<td>$narudzbaid</td>";
			echo "<td>$nazivproizvod</td>";
			echo "<td>$nazivkategorija</td>";
			echo "<td>$kolicina</td>";
			echo "<td>$cijena</td>";
			echo "<td>$datumkreiranja</td>";
			echo "<td>$blokirana</td>";
			echo "<td>$prihvacena</td>";
		echo "</tr>";
		}
	}
	else
	{
		echo "<tr><td colspan='$kol'>Nemate narudžbi</tr>";
	}
   echo "<tr>";
			echo " <td colspan='$kol' class='last'>";
			 echo "Stranice: ";
			 for($str=1;$str<=$broj_str;$str++){
				 echo " <a href=\"korisniknarudzbe.php?str=$str\">";
				 if($aktivna==$str){
					 echo "<mark>$str</mark>";
				 }
				 else
				 {
					echo "$str"; 
				 }				 
				 echo "</a>";
			 }
			echo "</td>";
			echo "</tr>";
   echo "</tbody>";
   echo "</table>";			
	
	if($aktivni_korisnik_tip == 1 || $aktivni_korisnik_tip == 0){
		 echo "<h3 style='clear:both'><a href='moderatornarudzbe.php'>Narudžbe iz kategorija koje moderiram</a></h3>";
	 }
	
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>