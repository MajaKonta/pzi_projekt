<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	<?php
	$reg=0;
	if(isset($_GET["reg"])){
		echo "<h2>Registracija korisnika</h2>";
		$reg=1;
	}
			if(isset($_GET["korisnik"]) || isset($_GET["novi"])){
	
			if(isset($_GET["korisnik"])){
	
				$id=$_GET["korisnik"];
				$sql="select * from korisnik where korisnik_id=".$id;
				$obradi=izvrsiBP($sql);
				list($idkor, $tip, $korime,$lozinka,$ime,$prezime,$email, $slika) = mysqli_fetch_array($obradi);
				$naslov="Ažuriranje postojećeg";
				$button="Ažuriraj";
			}
			else
			{

				$idkor=0;
				$tip=2;
				$korime="";
				$lozinka="";
				$ime="";
				$prezime="";
				$email="";
				$slika="";
				
				$naslov="Unos novog";
				$button="Unesi";
			}
		?>
		<h3><?php echo $naslov; ?> korisnika</h3>

		<form name="korisnik" id="korisnik" action="korisnik.php" method="POST" enctype="multipart/form-data" onsubmit="return ProvjeriKorisnik(this)">
			<input type="hidden" name="korisnikid" id="korisnikid" value="<?php echo $idkor; ?>">
			<input type="hidden" name="slikahidden" id="slikahidden" value="<?php echo $slika; ?>"/>
			<input type="hidden" name="registracija" id="registracija" value="<?php echo $reg; ?>"/>
			<table id="htmlform">
			<tr>
			<td>Korisničko ime:</td><td><input type="text" name="korime" id="korime" value="<?php echo $korime; ?>"
			<?php
			if($idkor>0){
				echo "readonly=\"readonly\"";
			}
			?>
			></td>
			</tr>
			<tr>
			<td>Ime:</td><td><input type="text" name="ime" id="ime" value="<?php echo $ime; ?>"></td>
			</tr>
			<tr>
			<td>Prezime:</td><td><input type="text" name="prezime" id="prezime" value="<?php echo $prezime; ?>"></td>
			</tr>
			<tr>
			<td>Lozinka:</td><td><input type="password" name="lozinka" id="lozinka" value="<?php echo $lozinka; ?>"></td>
			</tr>
			<tr>
			<td>Email:</td><td><input type="text" name="email" id="email" value="<?php echo $email; ?>"></td>
			</tr>
			<tr>
			<td>Tip korisnika:</td>
			<td>
			<select name="tip" id="tip">
			<?php
			if(isset($_GET["reg"])){
				echo "<option value='2'>korisnik</option>";
				
			}
			else
			{			
				$tipovi="select tip_id, naziv from tip_korisnika";
				$obradi=izvrsiBP($tipovi);
				
				while(list($id,$naziv)=mysqli_fetch_array($obradi)){

					echo "<option value=\"$id\"";
					if($tip==$id){
						echo " selected disabled";
					}
					echo ">$naziv</option>";
				}				
			}
			?>
			</select>
			</td>
			</tr>	
			<tr>
			<td>Slika:</td>
			<td>
			<input type="file" name="slika" id="slika">
			</td>
			</tr>	
			<td colspan="2"><input type="submit" name="KorisnikPost" id="KorisnikPost" value="<?php echo $button; ?>"></td>
			</tr>
			</table>
			</form>
<?php	
}
						
			if(isset($_POST['KorisnikPost'])) {
					$id = $_POST['korisnikid'];					
					$korime = $_POST['korime'];							
					$ime = $_POST['ime'];
					$prezime = $_POST['prezime'];
					$lozinka = $_POST['lozinka'];
					$email = $_POST['email'];
					$tip = $_POST['tip'];
					$registracija = $_POST['registracija'];
					
					$postojeca = $_POST['slikahidden'];
					
					$mjesto = "korisnici/";	

					$ime_dat = basename($_FILES['slika']['name']);
					
					if($ime_dat != ""){
					$slika = $mjesto.$ime_dat;	
					$stavi = move_uploaded_file($_FILES['slika']['tmp_name'],$slika);
					}
					else
					{
						if($postojeca != ""){
							$slika = $postojeca;
						}
						else
						{
							$slika = "korisnici/nophoto.jpg";
						}						
					}
										
					if ($id == 0) {					
						$sql = "INSERT INTO korisnik (tip_id, korisnicko_ime, lozinka, ime, prezime, email, slika)
						VALUES ('$tip', '$korime', '$lozinka', '$ime', '$prezime', '$email', '$slika')";
					} else {
						$sql = "UPDATE korisnik SET ime='$ime',prezime='$prezime',lozinka='$lozinka',email = '$email',tip_id = '$tip',slika = '$slika' 
						WHERE korisnik_id = '$id'";
					}
					
					$izvrsi = izvrsiBP($sql);
					
					if($registracija==1){
						$_SESSION["registracija"]="Uspješna registracija! Da biste se prijavili, vaš račun mora odobriti administrator!";
						header("Location: index.php");
						exit();
					}
					header("Location: korisnici.php");
			}


			if(isset($_GET["aktiviraj"])){				
				$idkorisnik=$_GET["aktiviraj"];
				$str=$_GET["str"];
				$sql = "UPDATE korisnik SET aktivan=1 where korisnik_id=".$idkorisnik;
				$izvrsi = izvrsiBP($sql);
				header("Location: korisnici.php?str=$str&korid=$idkorisnik");
			}
			
			if(isset($_GET["deaktiviraj"])){				
				$idkorisnik=$_GET["deaktiviraj"];
				$str=$_GET["str"];
				$sql = "UPDATE korisnik SET aktivan=0 where korisnik_id=".$idkorisnik;
				$izvrsi = izvrsiBP($sql);
				header("Location: korisnici.php?str=$str&korid=$idkorisnik");
			}
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>