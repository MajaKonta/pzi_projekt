<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	<h3>Popis svih kategorija
	
	<?php
		if(isset($_GET['azuriraj']) || isset($_GET['nova'])) {
	
		if(isset($_GET['azuriraj'])){
		$id = $_GET['azuriraj'];

		$sql = "SELECT * FROM kategorija WHERE kategorija_id=".$id;
		
		$izvrsi = izvrsiBP($sql);
		list($kategorijaid,$moderatorid,$naziv,$opis,$limit)=mysqli_fetch_row($izvrsi);
		$naslov="Ažuriranje postojeće";
		$button="Ažuriraj";
		
		
	} else {
		$kategorijaid=0;
		$moderatorid=0;
		$naziv="";
		$opis="";
		$limit=0;
		$naslov="Unos nove";
		$button="Unesi";
	}

	?>
	<h3><?php echo $naslov; ?> kategorije</h3>
		<form method="post" action="kategorija.php" id="kategorija" enctype="multipart/form-data" onsubmit="return ProvjeriKategoriju(this)">
			<input type="hidden" name="novi" value="<?php echo $kategorijaid;?>"/>
			<table id="htmlform">
			<tr>
			<td>Moderator:</td>
			<td>
			<select name="moderator" id="moderator">
			<?php
			$voditelji="select korisnik_id, ime, prezime from korisnik where tip_id = 1";
			
			$exsql=izvrsiBP($voditelji);		
			while(list($id,$ime,$prezime)=mysqli_fetch_array($exsql)){
				echo "<option value='$id'";
				if($moderatorid==$id){
					echo " selected";
				}
				echo ">$ime $prezime</option>";
			}
			?>
			</select>
			</td>
			</tr>			
				<tr>
					<td>
					<label for="naziv"><strong>Naziv:</strong></label>
					</td>
					<td>
					<input type="text" name="naziv" id="naziv" value="<?php echo $naziv; ?>"/>
					</td>
				</tr>
				<tr>
				<td>
				  <label for="opis"><strong>Opis:</strong></label>
					</td>
					<td>
					<textarea name="opis" id="opis" cols="30" rows="5"><?php echo $opis; ?></textarea>
					</td>
				</tr>	
				<tr>
					<td>
					<label for="limit"><strong>Limit:</strong></label>
					</td>
					<td>
					<input type="text" name="limit" id="limit" value="<?php echo $limit; ?>"/>
					</td>
				</tr>				
				<tr>
				  <td colspan="2">
					<input type="submit" name="KategorijaPost" id="KategorijaPost" value="<?php echo $button;?>"/>
				 </td>
				</tr>
			</table>
		</form>		
<?php
}


if(isset($_POST['KategorijaPost'])) {

		$id = $_POST['novi'];
		$moderator = $_POST['moderator'];	
		$naziv = $_POST['naziv'];	
		$opis = $_POST['opis'];
		$limit = $_POST['limit'];

		if ($id == 0) {		
			$sql = "INSERT INTO kategorija (moderator_id,naziv,opis,`limit`) values ('$moderator','$naziv', '$opis', '$limit')";
		} else {
			$sql = "UPDATE kategorija SET moderator_id='$moderator',naziv='$naziv', opis='$opis',`limit`='$limit' WHERE kategorija_id = ".$id;
		}
		$izvrsi = izvrsiBP($sql);
		
		header("Location: kategorije.php");					
	} 
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>