<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	<h3>Broj prihvaćenih i neprihvaćenih narudžbi po proizvodu:</h3>
	
	<h3>Pretraga</h3>
	<form name="pretraga" id="pretraga" action="prihvaceneneprihvacenenarudzbe.php" method="GET" onsubmit="return ProvjeriPretragu(this)">
	<table id="htmlform">
	<tr>
	<td>Kategorija:</td>
	<td>
	<select name="kategorija" id="kategorija">
	<?php
	$sql="select kategorija_id, naziv from kategorija";
	$izvrsikat=izvrsiBP($sql);
	while(list($id,$nazivkat)=mysqli_fetch_array($izvrsikat)){
		echo "<option value='$id'>$nazivkat</option>";
	}
	?>
	</select>
	</td>
	</tr>	
	<tr><td>Datum vrijeme od:</td><td><input type="text" name="DatumVrijemeOd" id="DatumVrijemeOd" placeholder="dd.mm.YYYY HH:ii:ss"></td></tr>
	<tr><td>Datum vrijeme do:</td><td><input type="text" name="DatumVrijemeDo" id="DatumVrijemeDo" placeholder="dd.mm.YYYY HH:ii:ss"></td></tr>
	<tr><td colspan="2"><input type="submit" name="PretragaNarudzbi" id="PretragaNarudzbi" value="Pretraži"></td></tr>
	<tr><td colspan="2">
	</td></tr>
	</table>
	</form>
	
	
      <?php	
	
		$sql = "SELECT
				pr.naziv AS 'Proizvod',
				kat.kategorija_id,
				kat.naziv AS 'Kategorija',
				sum(case when nar.prihvacena = 1 then 1 ELSE 0 end) AS 'prihvacenih', 
				sum(case when nar.prihvacena = 0 then 1 ELSE 0 end) AS 'neprihvacenih' 
				FROM narudzba nar
				INNER JOIN proizvod pr
				ON nar.proizvod_id = pr.proizvod_id
				INNER JOIN kategorija kat
				ON pr.kategorija_id = kat.kategorija_id"; 
			if(isset($_GET["PretragaNarudzbi"])){
			$datumod=$_GET["DatumVrijemeOd"];
			$datumdo=$_GET["DatumVrijemeDo"];
			$kategorija=$_GET["kategorija"];
				if(!empty($datumod) && !empty($datumdo) && !empty($kategorija)){
					$datumod=date("Y-m-d H:i:s",strtotime($datumod));
					$datumdo=date("Y-m-d H:i:s",strtotime($datumdo));
					$sql .= " where kat.kategorija_id = '$kategorija' AND nar.datum_kreiranja BETWEEN '$datumod' AND '$datumdo'";
				}
			}
			$sql .= " GROUP BY pr.proizvod_id";		

	$izvrsi=izvrsiBP($sql);
	$kol=4;
	echo "<h3>Rezultati";
	if(isset($_GET["PretragaNarudzbi"])){
		echo " pretrage između ".$_GET["DatumVrijemeOd"]." i ".$_GET["DatumVrijemeDo"]." i kategorije \"".SveKategorije()[$kategorija]."\":";
	}
	echo "</h3>";
	echo "<table id = \"dataview\">";
	echo "<thead>";
	echo "<tr>";
	echo "<th>Proizvod</th>";
	echo "<th>Kategorija</th>";
	echo "<th>Prihvaćenih</th>";
	echo "<th>Neprihvaćenih</th>";
	echo "</tr>";
	echo "</thead>";
	
	echo "<tbody>";
	if(mysqli_num_rows($izvrsi)>0){
		while(list($nazivproizvod, $kategorijaid, $nazivkategorija, $prihvacenih, $neprihvacenih)=mysqli_fetch_row($izvrsi)){			
			echo "<tr>";
			echo "<td>$nazivproizvod</td>";
			echo "<td>$nazivkategorija</td>";
			echo "<td>$prihvacenih</td>";
			echo "<td>$neprihvacenih</td>";
		echo "</tr>";
		}
	}
	else
	{
		echo "<tr><td colspan='4'>Nema podataka za tražene parametre</td></tr>";
	}
   echo "</tbody>";
   echo "</table>";			
	echo "<h3 style='clear:both'><a href='prihvaceneneprihvacenenarudzbe.php'>Ponovna pretraga</a></h3>";		
	?>
    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>