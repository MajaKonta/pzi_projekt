<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	<h3>Popis svih kategorija i proizvoda
	
	<?php
		if($aktivni_korisnik_tip==1){
			echo " koje ja moderiram";
		}
	?>
	
	:</h3>
      <?php	
	
			$sql = "SELECT
			kat.moderator_id,
kat.kategorija_id,
kat.naziv,
kat.opis,
kat.limit,
pr.proizvod_id,
pr.naziv,
pr.cijena
FROM kategorija kat
left JOIN proizvod pr
ON kat.kategorija_id = pr.kategorija_id";
	if($aktivni_korisnik_tip==1){
		$sql.=" where kat.moderator_id = ".$aktivni_korisnik_id;
	}
	$izvrsi=izvrsiBP($sql);	 
	$broj_redaka = mysqli_num_rows($izvrsi);
	$broj_str = ceil($broj_redaka / $vel_str);	
	$sql .= " limit ".$vel_str;		
	
	if (isset($_GET['str'])){
		$sql = $sql . " OFFSET " . (($_GET['str'] - 1) * $vel_str);
		$aktivna = $_GET['str'];
	} else {
		$aktivna = 1;
	}

	$izvrsi=izvrsiBP($sql);
	$kol=6;
	echo "<table id = \"dataview\">";
	echo "<thead>";
	echo "<tr>";
	echo "<th>ID Kategorije</th>";
	echo "<th>Naziv Kategorije</th>";
	echo "<th>Opis</th>";
	echo "<th>Limit</th>";
	echo "<th>Proizvod</th>";
	echo "<th>Cijena</th>";
		if($aktivni_korisnik_tip==0 || $aktivni_korisnik_tip==1){
			echo "<th>Opcija</th>";
			$kol=7;
		}
	echo "</tr>";
	echo "</thead>";
	
	echo "<tbody>";
	while(list($kategorijaid,$moderatorid, $naziv, $opis, $limit, $proizvodid,$proizvodnaziv,$cijena)=mysqli_fetch_row($izvrsi)){
		$azur="<a href='proizvod.php?azuriraj=$proizvodid'>Ažuriraj</a>";
		echo "<tr>";
		echo "<td>$kategorijaid</td>";
		echo "<td>$naziv</td>";
		echo "<td>$opis</td>";
		echo "<td>$limit</td>";
		echo "<td>$proizvodnaziv</td>";
		echo "<td>$cijena</td>";
		if(($aktivni_korisnik_tip==0 || $aktivni_korisnik_tip==1) && $proizvodid != null){
			echo "<td>$azur</td>";
		}
		else
		{
			echo "<td></td>";
		}
	echo "</tr>";
	}
   echo "<tr>";
			echo " <td colspan='$kol' class='last'>";
			 echo "Stranice: ";
			 for($str=1;$str<=$broj_str;$str++){
				 echo " <a href=\"moderatorkategorijeproizvodi.php?str=$str\">";
				 if($aktivna==$str){
					 echo "<mark>$str</mark>";
				 }
				 else
				 {
					echo "$str"; 
				 }				 
				 echo "</a>";
			 }
			echo "</td>";
			echo "</tr>";
   echo "</tbody>";
   echo "</table>";
		
	if($aktivni_korisnik_tip==1 || $aktivni_korisnik_tip==0){
		echo "<p><a href=\"proizvod.php?novi=1\">Dodaj novi proizvod</p>";
	}
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>