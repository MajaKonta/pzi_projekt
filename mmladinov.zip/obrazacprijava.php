    <div id="login" class="boxed">
      <h2 class="title">Prijava</h2>
      <div class="content">
	      <?php
		 if(!isset($_SESSION['aktivni_korisnik'])){
		  ?>
        <form id="form1" method="post" action="prijava.php">
          <fieldset>
          <legend>Upišite podatke</legend>
          <label for="inputtext1">Korisničko ime:</label>
          <input id="inputtext1" type="text" name="korisnicko_ime" value="" />
          <label for="inputtext2">Lozinka:</label>
          <input id="inputtext2" type="password" name="lozinka" value="" />
          <input id="inputsubmit1" type="submit" name="inputsubmit1" value="Prijavi se" />
          </fieldset>
        </form>
		<?php
			$poruka="Niste prijavljeni!";
			if(isset($_SESSION["errorinfo"])){
				$poruka=$_SESSION["errorinfo"];
				unset($_SESSION["errorinfo"]);
			}
			echo "<span class='poruka'>$poruka</span>";
			echo "<br><span class='poruka'><a href='korisnik.php?novi=1&reg=1'>Registracija</a></span>";
		  }
		  else
		  {
			echo "<h3><strong>Vi ste:</strong> ".$_SESSION['aktivni_korisnik']."</h3>";
			echo "<h3>Tip: ".$_SESSION['aktivni_korisnik_tipime']."</h3>";
			echo "<p class=\"odjava\"><a href=\"odjava.php\">Odjava</a></p>";
		  }
		  ?>
      </div>
    </div>