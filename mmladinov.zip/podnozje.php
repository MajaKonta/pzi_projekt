<div id="footer">
  <p id="legal">Copyright &copy; Maja Mladinov Konta. All Rights Reserved. Designed by <a href="">Maja Mladinov Konta</a>.</p>
</div>
</body>
</html>