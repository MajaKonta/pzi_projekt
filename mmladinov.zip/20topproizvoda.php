<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
      <h3>20 top najprodavanijih proizvoda
	  
		<?php 
			if($aktivni_korisnik_tip != -1){
			echo "<label class='desno'>=> <a href='sviproizvodigalerija.php'>Svi ostali proizvodi - galerija</label></a>";
			}
		?>
	  
	  </h3>
      <?php
	
	$sql = "SELECT
pr.proizvod_id,
pr.naziv,
sum(nar.kolicina*pr.cijena) AS 'Ukupno',
pr.slika,
nar.prihvacena
FROM narudzba nar
INNER JOIN proizvod pr
ON nar.proizvod_id = pr.proizvod_id
WHERE nar.prihvacena = 1
GROUP BY pr.proizvod_id
ORDER BY Ukupno DESC LIMIT 20";		
	$izvrsi=izvrsiBP($sql);	 
	$count=0;
	while(list($proizvodid,$naziv, $ukupno, $slika,$prihvacena)=mysqli_fetch_row($izvrsi)){
		$count++;
		?>
		<div class="gallery">
		<a target="_blank" href="<?php echo $slika; ?>">
		<img src="<?php echo $slika; ?>" title="<?php echo $naziv; ?>" width="400" height="240">
		</a>
		<div class="desc"><?php echo $naziv; ?></div>
		</div>		
		<?php
		if($count%3==0){
			echo "<br style='clear:both'>";
		}		
	}
	
	echo "<hr style='clear:both'>";

	?>
    
	<p></p>
    </div>
    	<?php 
	if($aktivni_korisnik_tip != -1){
		 echo "<h3 style='clear:both'><a href='sviproizvodigalerija.php'>Svi ostali proizvodi</a></h3>";
	 }
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>