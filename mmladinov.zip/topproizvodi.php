    <div id="updates" class="boxed">
      <h2 class="title">Top proizvodi</h2>
	  <?php
	
	$sql = "SELECT
pr.proizvod_id,
pr.naziv,
pr.opis,
sum(nar.kolicina*pr.cijena) AS 'Ukupno',
pr.slika,
nar.prihvacena
FROM narudzba nar
INNER JOIN proizvod pr
ON nar.proizvod_id = pr.proizvod_id
WHERE nar.prihvacena = 1
GROUP BY pr.proizvod_id
ORDER BY Ukupno DESC LIMIT 20";		
	$izvrsi=izvrsiBP($sql);	 
	?>
      <div class="content">
        <ul>
		<?php
			while(list($proizvodid,$naziv,$opis, $ukupno, $slika,$prihvacena)=mysqli_fetch_row($izvrsi)){
		?>
          <li>
            <h3><?php echo $naziv; ?></h3>
            <p><a href="#"><?php echo $opis; ?></a></p>
          </li>
		<?php
			}
		?>
        </ul>

      </div>
    </div>