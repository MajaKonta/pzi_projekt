<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
      <h3>Popis svih proizvoda</h3>
      <?php	  
	$sql = "SELECT
kat.kategorija_id,
kat.naziv,
pr.proizvod_id,
pr.naziv,
pr.slika
FROM kategorija kat
INNER JOIN proizvod pr
ON kat.kategorija_id = pr.kategorija_id
ORDER BY kat.naziv";		
	$izvrsi=izvrsiBP($sql);	 
	$count=0;
	while(list($kategorijaid,$kategorijanaziv, $proizvodid, $proizvodnaziv, $slika)=mysqli_fetch_row($izvrsi)){
		$count++;
		?>
		<div class="gallery">
		<a target="_blank" href="<?php echo $slika; ?>">
		<img src="<?php echo $slika; ?>" title="<?php echo $proizvodnaziv; ?>" width="400" height="240">
		</a>
			<div class="desckosarica">
			<?php echo "<strong>Kategorija:</strong> ".$kategorijanaziv."<br>"; ?>
			<?php echo "<strong>Proizvod:</strong> ".$proizvodnaziv."<br>"; ?>
			<?php 
				if(isset($_SESSION["proizvodi"]))
				{
				  if(array_key_exists($proizvodid,$_SESSION["proizvodi"])){
						echo "<strong>Info: </strong>Proizvod u košarici - <a href='kosarica.php?makniproizvod=$proizvodid'>Makni</a><br>";
					}				
					else
					{
						echo "<strong>Akcija:</strong> <a href='kosarica.php?dodajproizvod=$proizvodid'>Dodaj u košaricu</a><br>";
					}
					
				}
				else
				{
					echo "<strong>Akcija:</strong> <a href='kosarica.php?dodajproizvod=$proizvodid'>Dodaj u košaricu</a><br>";
				}
			 
			?>
			</div>
		</div>		
		<?php
		if($count%3==0){
			echo "<br style='clear:both'>";
		}
	}		
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>