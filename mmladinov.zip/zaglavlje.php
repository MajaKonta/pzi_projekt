<?php
if(session_status()==PHP_SESSION_NONE){
session_start();	
}
	$aktivni_korisnik=0;
	$aktivni_korisnik_tip=-1;
	$aktivni_korisnik_id=0;		
	$ime_tip="";
	if(isset($_SESSION['aktivni_korisnik'])){
		$aktivni_korisnik=$_SESSION['aktivni_korisnik'];
		$aktivni_korisnik_id=$_SESSION["aktivni_korisnik_id"];
		$aktivni_korisnik_ime=$_SESSION['aktivni_korisnik_ime'];
		$aktivni_korisnik_tip=$_SESSION['aktivni_korisnik_tip'];
		$aktivni_korisnik_tipime=$_SESSION['aktivni_korisnik_tipime'];
		$aktivni_korisnik_slika=$_SESSION['aktivni_korisnik_slika'];		
	}
	
		$dbc = mysqli_connect('localhost', 'root', '','');
		$sql="SELECT SCHEMA_NAME
		  FROM INFORMATION_SCHEMA.SCHEMATA
		 WHERE SCHEMA_NAME = 'online_oprema'";
		 $ex = mysqli_query($dbc,$sql);
		 if(mysqli_num_rows($ex)==0){
			 require_once("bazapodaci.php");
			 exit();
		 }
		 else
		 {
			 include("spojnabazu.php");
		 }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>::Kupaonice::</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link href="default.css" rel="stylesheet" type="text/css" />
<script src="js/provjere.js"></script>
</head>
<body>
<div id="header">
<?php
include("topmenu.php");
?>
  <div id="logo">
    <h1><a href="#">Opremite svoju kupaonicu</a></h1>
    <h2><a href="#">Sve za kupaonice</a></h2>
  </div>
</div>
<?php
include("mainmenu.php");
?>