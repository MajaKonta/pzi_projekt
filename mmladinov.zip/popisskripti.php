<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	<h3>Popis svih skripti</h3>	
	<?php		
		echo "<table id=\"dataview\">";
		echo "<tr>";
		echo "<th>Naziv skripte</th><th>Opis skripte</th><th>Rola</th>";
		echo "</tr>";
		echo "<tbody>";
		echo "<tr><td>20topproizvoda.php</td><td>Skripta daje prvih top 20 najprodavanijih proizvoda</td><td>Neregistrirani korisnik</td></tr>";
		echo "<tr><td>adminnarudzbe.php</td><td>Popis svih narudžbi koje postoje</td><td>Administrator</td></tr>";
		echo "<tr><td>index.php</td><td>Početna stranica sa opisom zadatka</td><td>Svi</td></tr>";
		echo "<tr><td>kategorija.php</td><td>Skripta koja omogućuje unos nove i ažuriranje postojeće kategorije</td><td>Administrator</td></tr>";
		echo "<tr><td>kategorije.php</td><td>Skripta koja daje popis svih kategorija</td><td>Administrator</td></tr>";
		echo "<tr><td>korisnici.php</td><td>Skripta koja daje popis svih korisnika</td><td>Administrator</td></tr>";
		echo "<tr><td>korisnik.php</td><td>Skripta koja omogućuje unos novog i ažuriranje postojećeg korisnika</td><td>Administrator</td></tr>";
		echo "<tr><td>korisniknarudzbe.php</td><td>Skripta koja daje popis svih narudžbi za registriranog korisnika</td><td>Administrator, Voditelj, Registrirani korisnik</td></tr>";
		echo "<tr><td>kosarica.php</td><td>Skripta koja omogućuje dodavanje novih proizvoda u košaricu i micanje iz nje</td><td>Administrator, Voditelj, Registrirani korisnik</td></tr>";
		echo "<tr><td>mainmenu.php</td><td>Glavni izbornik</td><td>Svi</td></tr>";
		echo "<tr><td>moderatorkategorijeproizvodi.php</td><td>Skripta koja daje popis svih proizvoda po kategoriji moderatora</td><td>Administrator</td></tr>";
		echo "<tr><td>moderatornarudzbe.php</td><td>Skripta koja daje popis svih narudžbi za kategorije moderatora</td><td>Administrator, Voditelj</td></tr>";
		echo "<tr><td>narudzba.php</td><td>Skripta koja omogućuje realizaciju naružbe, odustajanje od nje i dr.</td><td>Administrator, Voditelj, Registrirani korisnik</td></tr>";
		echo "<tr><td>obrazacprijava.php</td><td>Skripta koja omogućuje prikaz login obrasca ili podataka o prijavljenom korisniku</td><td>Administrator, Voditelj, Registrirani korisnik</td></tr>";
		echo "<tr><td>odjava.php</td><td>Skripta koja omogućuje odjavu korisnika sa sustava</td><td>Administrator, Voditelj, Registrirani korisnik</td></tr>";
		echo "<tr><td>podnozje.php</td><td>Skripta koja jednoznačno opisuje podnožje stranice</td><td>Svi</td></tr>";
		echo "<tr><td>prihvaceneneprihvacenenarudzbe.php</td><td>Skripta koja omogućuje pretragu prihvaćenih i neprihvaćenih narudžbi</td><td>Administrator</td></tr>";
		echo "<tr><td>prijava.php</td><td>Skripta koja omogućuje prijavu korisnika na sustav</td><td>Administrator, Voditelj, Registrirani korisnik</td></tr>";
		echo "<tr><td>proizvod.php</td><td>Skripta koja omogućuje unos novog proizvoda ili ažuriranje postojećeg</td><td>Administrator, Voditelj</td></tr>";
		echo "<tr><td>spojnabazu.php</td><td>Skripta koja omogućuje spoj na bazu</td><td>Svi</td></tr>";
		echo "<tr><td>sviproizvodigalerija.php</td><td>Skripta koja omogućuje ispis svih proizvoda u obliku galerije i dodavanje u košaricu istih</td><td>Administrator, Voditelj, Registrirani korisnik</td></tr>";
		echo "<tr><td>topmenu.php</td><td>Skripta koja prikazuje top menu (košarica, o autoru rada, popis skripti)</td><td>Svi</td></tr>";
		echo "<tr><td>topproizvodi.php</td><td>Skripta koja sa desne strane učitava top 20 najprodavanijih proizvoda</td><td>Administrator, Voditelj, Registrirani korisnik</td></tr>";
		echo "<tr><td>zaglavlje.php</td><td>Skripta koja sadrži ključne elemente za ponašanje cijele aplikacije (uvoz zagljavlja, definiranih varijabli za prijavu, deklaraciju css i js datoteka</td><td>Neregistrirani korisnik</td></tr>";
		echo "</tbody>";
		echo "</table>";	
	?>
    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 
?>
  </div>
</div>
<?php require("podnozje.php"); ?>