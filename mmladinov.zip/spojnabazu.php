<?php

$vel_str = 5;

$dbc = mysqli_connect('localhost', 'root', '','online_oprema');
if(mysqli_connect_errno()){
	die("Greška kod spajanja na bazu online_oprema: ".mysqli_connect_error());
}

mysqli_set_charset($dbc,"utf8");


function izvrsiBP($sql) {
	global $dbc;
	$rs = mysqli_query($dbc,$sql);
	if(!$rs) {
		die("Greška kod izvršavanja upita: ".mysqli_error($dbc));
	}
	return $rs;
}
	
function zatvoriBP(){
	global $dbc;
	if(is_resource($dbc)){
	mysqli_close($dbc);
	}
}

function Natrag(){
	
	echo "<p style='clear:both'><a href='javascript:history.back(-1)'>Natrag</a></p>";
}

function ProvjeriSpremnost(){
	$dbc = mysqli_connect('localhost', 'root', '','');
	$sql="SELECT SCHEMA_NAME
  FROM INFORMATION_SCHEMA.SCHEMATA
 WHERE SCHEMA_NAME = 'online_oprema'";
 $ex = mysqli_query($dbc,$sql);
 if(mysqli_num_rows($ex)==0){
	 return 1;
 }
 else
 {
	 return 0;
 }
	
}


function PreostaloLimitaUKategoriji($kategorijaid){
	
		$sql="SELECT 
nova.ukupnoprodano,
nova.kategorija_id,
nova.`limit`,
(nova.`limit`-nova.ukupnoprodano) AS 'ostalo'
FROM(
SELECT
case when sum(nar.kolicina*pr.cijena) IS NULL
then 0 ELSE sum(nar.kolicina*pr.cijena) END
AS 'ukupnoprodano',
kat.kategorija_id,
kat.`limit` from
narudzba nar
INNER JOIN proizvod pr
ON nar.proizvod_id = pr.proizvod_id
INNER JOIN kategorija kat
ON pr.kategorija_id = kat.kategorija_id
WHERE kat.kategorija_id = ".$kategorijaid." AND nar.prihvacena = 1) as nova";
		$ex = izvrsiBP($sql);
		list($ukupnoprodano,$katid,$limit,$ostalo)=mysqli_fetch_array($ex);
		
		if($ostalo<0){
			$ostalo=0;
		}
		
		return $ostalo;
}

function UkupnoNarudzbiPoKategoriji($kategorijaid){
	
	$sql="SELECT
		nar.narudzba_id,
		(nar.kolicina*pr.cijena) AS 'ukupno',
		kat.kategorija_id,
		kat.`limit`,
		nar.prihvacena
		FROM
		narudzba nar
		INNER JOIN proizvod pr
		ON nar.proizvod_id = pr.proizvod_id
		INNER JOIN kategorija kat
		ON pr.kategorija_id = kat.kategorija_id
		WHERE kat.kategorija_id = ".$kategorijaid;
		$ex = izvrsiBP($sql);
		return mysqli_num_rows($ex);
	
}


function PrihvaceneNeprihvaceneNarudzbe($proizvodid,$prihvacen){
	
	$sql="SELECT
		nar.narudzba_id,
		(nar.kolicina*pr.cijena) AS 'ukupno',
		kat.kategorija_id,
		kat.`limit`,
		nar.prihvacena
		FROM
		narudzba nar
		INNER JOIN proizvod pr
		ON nar.proizvod_id = pr.proizvod_id
		INNER JOIN kategorija kat
		ON pr.kategorija_id = kat.kategorija_id
		WHERE kat.kategorija_id = ".$kategorijaid;
		$ex = izvrsiBP($sql);
		return mysqli_num_rows($ex);
	
}


function SveKategorije(){
	
	$sql="SELECT kategorija_id, naziv from kategorija";
		$ex = izvrsiBP($sql);
		
		$kategorije=array();
		while(list($katid,$naziv)=mysqli_fetch_array($ex)){
			$kategorije[$katid]=$naziv;
		}
		
		return $kategorije;
}


function PrikazVideoFormata($video){
	
		if(strpos($video,"youtube")>0){ 
			$youtubevideo="https://www.youtube.com/embed/videouid";
			$poz=strpos($video,"=");
			$video_id = substr($video,$poz+1,strlen($video));
			$video=str_replace("videouid",$video_id,$youtubevideo); 
			echo "<iframe width=\"250\" height=\"200\" src=\"$video\"></iframe>";
		}


		if(substr($video,-3)=="mp4"){
			echo "<video width=\"240\" height=\"130\" controls>";
			echo "<source src=\"$video\" type=\"video/mp4\">";
			echo "<source src=\"$video\" type=\"video/webm\">";
			echo "</video>";
		}
}
?>