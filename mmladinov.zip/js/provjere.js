function ProvjeriUnosProizvoda(){
  let PopisGresaka="";
  let BrojGresaka=0;


    let naziv = document.getElementById("naziv");
		if(naziv.value==""){
			PopisGresaka+="<br>Niste unijeli naziv proizvoda!";
			BrojGresaka++;
		}

    let opis = document.getElementById("opis");
		if(opis.value==""){
			PopisGresaka+="<br>Niste unijeli opis proizvoda!";
			BrojGresaka++;
		}

    let cijena = document.getElementById("cijena");
		if(cijena.value=="" || cijena.value==0){
			PopisGresaka+="<br>Niste unijeli cijenu proizvoda!";
			BrojGresaka++;
		}

    let slika = document.getElementById("slika");
		if(slika.value==""){
			PopisGresaka+="<br>Niste unijeli url slike proizvoda!";
			BrojGresaka++;
		}

    let video = document.getElementById("video");
		if(video.value==""){
			PopisGresaka+="<br>Niste unijeli url za video proizvoda!";
			BrojGresaka++;
		}
		
    if(BrojGresaka>0){
      PrikaziPogreske(BrojGresaka,PopisGresaka);
      return false;
    }	
  return true;	
}

function ProvjeriKorisnik(){

	let PopisGresaka="";
	let BrojGresaka=0;

	let korime = document.getElementById("korime");
	if(korime.value==""){
		PopisGresaka+="<br>Niste unijeli korisničko ime!";
		BrojGresaka++;
	}
	

	let ime = document.getElementById("ime");
	if(ime.value==""){
		PopisGresaka+="<br>Niste unijeli ime!";
		BrojGresaka++;
	}
	
	let prezime = document.getElementById("prezime");
	if(prezime.value==""){
		PopisGresaka+="<br>Niste unijeli prezime!";
		BrojGresaka++;
	}
	
	let lozinka = document.getElementById("lozinka");
	if(lozinka.value==""){
		PopisGresaka+="<br>Niste unijeli lozinku!";
		BrojGresaka++;
	}
	
	let tip = document.getElementById("tip");
	if(tip.value=="odb"){
		PopisGresaka+="<br>Niste odabrali tip!";
		BrojGresaka++;
	}
	
	let email = document.getElementById("email");
	if(email.value==""){
		PopisGresaka+="<br>Niste upisali email!";
		BrojGresaka++;
	}

if(BrojGresaka>0){
  PrikaziPogreske(BrojGresaka,PopisGresaka);
  return false;
}	
return true;	
}

function ProvjeriKategoriju(){
  let PopisGresaka="";
  let BrojGresaka=0;


    let naziv = document.getElementById("naziv");
		if(naziv.value==""){
			PopisGresaka+="<br>Niste unijeli naziv kategorije!";
			BrojGresaka++;
		}

    let opis = document.getElementById("opis");
		if(opis.value==""){
			PopisGresaka+="<br>Niste unijeli opis kategorije!";
			BrojGresaka++;
		}

    let limit = document.getElementById("limit");
		if(limit.value=="" || limit.value==0){
			PopisGresaka+="<br>Niste unijeli novčani limit kategorije!";
			BrojGresaka++;
		}

    if(BrojGresaka>0){
      PrikaziPogreske(BrojGresaka,PopisGresaka);
      return false;
    }	
  return true;	
}


function ProvjeriNarudzbu(){
  let PopisGresaka="";
  let BrojGresaka=0;


    let kolicina = document.getElementById("kolicina");
		if(kolicina.value=="" || kolicina.value==0){
			PopisGresaka+="<br>Niste unijeli količinu proizvoda kojeg naručujete!";
			BrojGresaka++;
		}


    if(BrojGresaka>0){
      PrikaziPogreske(BrojGresaka,PopisGresaka);
      return false;
    }	
  return true;	
}


function ProvjeriPretragu(){
  let PopisGresaka="";
  let BrojGresaka=0;


    let DatumVrijemeOd = document.getElementById("DatumVrijemeOd");
		if(DatumVrijemeOd.value==""){
			PopisGresaka+="<br>Niste unijeli datum pretrage od!";
			BrojGresaka++;
		}
	let datvrijeme = /(0[1-9]|[1-2][0-9]|3[0-1])+\.(0[1-9]|1[0-2])+\.[0-9]{4} (2[0-3]|[01][0-9]):[0-5][0-9]:[0-5][0-9]/;
	
	    if(datvrijeme.test(DatumVrijemeOd.value) == false) {
		  PopisGresaka+="<br>Pogresan oblik datuma i vremena od (mora biti dd.mm.YYYY hh:ii:ss)";
		  BrojGresaka++;
		}

    let DatumVrijemeDo = document.getElementById("DatumVrijemeDo");
		if(DatumVrijemeDo.value==""){
			PopisGresaka+="<br>Niste unijeli datum pretrage do!";
			BrojGresaka++;
		}
	
	    if(datvrijeme.test(DatumVrijemeDo.value) == false) {
		  PopisGresaka+="<br>Pogresan oblik datuma i vremena do (mora biti dd.mm.YYYY hh:ii:ss)";
		  BrojGresaka++;
		}	

    if(BrojGresaka>0){
      PrikaziPogreske(BrojGresaka,PopisGresaka);
      return false;
    }	
  return true;	
}

function PrikaziPogreske(BrojGresaka,PopisGresaka){
  let row = document.getElementById("errors");
    if(row != null){
      row.parentNode.removeChild(row);
    }
    let table = document.getElementById("htmlform");
    let tr = table.insertRow();
    let td = tr.insertCell();
    td.innerHTML="<p><strong><u>Pronađeno je "+BrojGresaka+" grešaka:</u></strong>"+PopisGresaka+"</p>";
    td.innerHTML+="<p><strong><u>Ispravite greške pa nastavite sa spremanjem!</u></strong></p>";
    td.colSpan=2
    td.id="errors";
    td.style.backgroundColor = "#EA672E";
    td.style.fontSize = "12px";
}