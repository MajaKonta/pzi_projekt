<?php require("zaglavlje.php");
 
	if($aktivni_korisnik_tip==1){
		header("Location: moderatornarudzbe.php");
	}
?>
<div id="content">
  <div id="main">
    <div id="welcome">
	<?php
	if(isset($_SESSION["registracija"])){
      echo "<h1 class='reg'>".$_SESSION["registracija"]."</h1>";
	  unset($_SESSION["registracija"]);
	}
	  ?>
      <h2>Projektni zadatak</h2>
      <p><strong>Uloge: administrator, moderator, registrirani korisnik i anonimni/neregistrirani korisnici.</strong><br/>Sustav služi za naručivanje opreme za kupaonice. Sustav mora imati moguénost prijave i odjave korisnika sa sustava.<br/>
	  U sustavu postoji jedan ugradeni administrator (korisničko ime:
admin, lozinka: admin). Administrator je prijavljeni korisnik koji ima vrstu jednaku jedan. Sustav ima ugrađeno dodavanje stavki u košaricu, daljnje naručivanje, te micanje stavki iz košarice.</p>      
    </div>
    <div id="example">
      <h3>Anonimni/neregistrirani korisnik</h3>
      <p>Anonimni/neregistrirani korisnik može samo vidjeti 20 najprodavanijih proizvoda u obliku galerije slika.</p>   
      <h3>Registrirani korisnik</h3>
      <p>Registrirani korisnik uz svoje funkcionalnosti ima i sve funkcionalnosti kao i neprijavljeni korisnik. Vidi popis proizvoda kao galeriju slika sredeno/sortirano po kategorijama. Može staviti proizvod u košaricu (košarica je aktivna samo za vrijeme trajanja sesije). Može pregledavati proizvode u košarici te maknuti iz košarice ili naručiti iste uz navodenje količine jedan po jedan. U jednoj narudžbi može naručiti samo jedan proizvod (narudžba se ne može mijenjati). Korisnik vidi popis svojih naručenih proizvoda uz obavezni prikaz informacija o statusu narudžbe, datumu kreiranja i naziva proizvoda.</p>
	  <h3>Moderator</h3>
      <p>Moderator uz svoje funkcionalnosti ima i sve funkcionalnosti kao i registrirani korisnik. Unosi, azurira i pregledava proizvode za svoje kategorije. Kod unosa proizvoda mora unijeti naziv, opis i cijenu, postaviti sliku (URL do slike na Webu) i video (URL do videa na Webu). Nakon prijave vidi popis narudžbi za kategorije kojima upravlja sredeno/sortirano po kategorijama. Ukoliko narudžba ima iznos veći od iznosa definiranog na kategoriji administrator je mora prvo odobriti. Mogućnost prihvaćanja/odbijanja je blokirana sve dok administrator ne odobri. Moderator prihvaća ili odbija narudžbe za svoje kategorije.</p>
      <h3>Administrator</h3>
      <p>Administrator uz svoje funkcionalnosti ima i sve funkcionalnosti kao i moderator. Unosi, ažurira i pregledava korisnike sustava te definira i azurira njihove tipove. Unosi, pregledava i ažurira kategorije opreme (npr. keramika, elektronika, pomoćni materijali, ...)
Kod unosa kategorije mora unijeti naziv i opis, odabrati moderatora za kategoriju izmedu korisnika koji imaju tip moderator, definirati iznos nakon kojeg treba moderator dobiti odobrenje administratora za potvrdu narudžbe. Jedna kategorija može imati samo jednog moderatora, a jedan moderator moie upavljati sa više kategorija. Administrator ima pregled narudžbi koje imaju iznos iznad iznosa definiranog za kategoriju (polje limit u bazi) te pojedine od njih može odobriti. Ukoliko administrator ne odobri narudžbu ona ostaje blokirana i ne može je moderator prihvatiti. Administrator vidi po pojedinom proizvodu ukupan broj prihvaćenih narudžbi i neprihvaćenih narudžbi, a podatke može filtrirati na temelju kategorije i vremenskog razdoblja kreiranja narudžbe. Razdoblje se definira datumom i vremenom od i do.</p>
    </div>
  </div>
  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 
?>
  </div>
</div>
<?php require("podnozje.php"); ?>