<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	
	<?php
		if(isset($_GET['azuriraj']) || isset($_GET['novi'])) {
	
		if(isset($_GET['azuriraj'])){
		$id = $_GET['azuriraj'];

		$sql = "SELECT * FROM proizvod WHERE proizvod_id=".$id;
		
		$izvrsi = izvrsiBP($sql);
		list($proizvodid,$kategorijaid,$naziv,$opis,$cijena,$slika,$video)=mysqli_fetch_row($izvrsi);
		$naslov="Ažuriranje postojećeg";
		$button="Ažuriraj";
		
		
	} else {
		$proizvodid=0;
		$kategorijaid=0;
		$naziv="";
		$opis="";
		$cijena=0;
		$slika="";
		$video="";
		$naslov="Unos novog";
		$button="Unesi";
	}

	?>
	<h3><?php echo $naslov; ?> proizvoda</h3>
		<form method="post" action="proizvod.php" id="kategorija" enctype="multipart/form-data" onsubmit="return ProvjeriUnosProizvoda(this)">
			<input type="hidden" name="novi" value="<?php echo $id; ?>"/>
			<table id="htmlform">	
				<tr>
				<td>Kategorija:</td>
				<td>
				<select name="kategorija" id="kategorija">
				<?php
				$sql="select kategorija_id, naziv from kategorija";
				if($aktivni_korisnik_tip==1){
				$sql.="	where moderator_id = ".$aktivni_korisnik_id;
				}
				$izvrsikat=izvrsiBP($sql);
				while(list($id,$nazivkat)=mysqli_fetch_array($izvrsikat)){
					echo "<option value='$id'";
					if($id==$kategorijaid) {
						echo " selected";
					}
					echo ">$nazivkat</option>";
				}
				?>
				</select>
				</td>
				</tr>			
				<tr>
				<td>
				<label for="naziv"><strong>Naziv:</strong></label>
					</td>
					<td>
					<input type="text" name="naziv" id="naziv" value="<?php echo $naziv; ?>"/>
					</td>
				</tr>
				<tr>
				<td>
				  <label for="opis"><strong>Opis:</strong></label>
					</td>
					<td>
					<textarea name="opis" id="opis" cols="30" rows="5"><?php echo $opis; ?></textarea>
					</td>
				</tr>
				<tr>
				<td>
				<label for="cijena"><strong>Cijena:</strong></label>
					</td>
					<td>
					<input type="text" name="cijena" id="cijena" value="<?php echo $cijena; ?>"/>
					</td>
				</tr>
				<tr>
				<td>Slika</td>
				<td>
				<?php
				if($slika!=""){
					echo "<br><img src='$slika' width='160px' height='160px'>";
				}
				?>
				<input type="text" name="slika" id="slika" value="<?php echo $slika; ?>" size="35">
				</td>
				</tr>
				<tr>
				<td>URL video</td>
				<td>
				<?php
				if($video!=""){
					PrikazVideoFormata($video);
				}
				?>
				<input type="text" name="video" id="video" value="<?php echo $video; ?>" size="35">
				</td>
				</tr>
				<tr>
				  <td colspan="2">
					<input type="submit" name="ProizvodPost" id="ProizvodPost" value="Spremi"/>
				 </td>
				</tr>
			</table>
		</form>		
<?php
}


if(isset($_POST['ProizvodPost'])) {

		$id = $_POST['novi'];
		$naziv = $_POST['naziv'];	
		$opis = $_POST['opis'];
		$kategorija = $_POST['kategorija'];
		$cijena = $_POST['cijena'];
		$slika = $_POST['slika'];
		$video = $_POST['video'];

		
		if ($id == 0) {		
			$sql = "INSERT INTO proizvod (kategorija_id, naziv, opis, cijena, slika, video) values ('$kategorija','$naziv', '$opis','$cijena','$slika','$video')";
		} else {
			$sql = "UPDATE proizvod SET kategorija_id='$kategorija',naziv='$naziv', opis='$opis', cijena='$cijena', slika='$slika', video='$video' WHERE proizvod_id = ".$id;
		}
		$izvrsi = izvrsiBP($sql);
		
		header("Location: moderatorkategorijeproizvodi.php");					
	} 
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>