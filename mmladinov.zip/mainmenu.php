<div id="menu">
  <ul>
    <li class="first"><a href="index.php">Početna</a></li>
    <li><a href="20topproizvoda.php">Proizvodi</a></li>
    <?php
	  switch($aktivni_korisnik_tip){		  
		  case 0:
		  ?>
		  <li><a href="korisnici.php">Korisnici</a></li>
		  <li><a href="kategorije.php">Kategorije</a></li>
		  <li><a href="adminnarudzbe.php">Narudžbe</a></li>
		  <?php
		  break;
		  case 1:
		  ?>
		  <li><a href="moderatorkategorijeproizvodi.php">Kategorije</a></li>
		  <li><a href="moderatornarudzbe.php">Narudžbe</a></li>
		  <?php
		  break;
		  case 2:
		  ?>
		  <li><a href="korisniknarudzbe.php">Narudžbe</a></li>
		  <?php
		  break;
	  }
	  ?>
  </ul>
</div>