<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	<h3>Popis svih korisnika</h3>
	
	<?php
			$sql="select k.korisnik_id, k.tip_id,k.korisnicko_ime,k.ime,k.prezime,k.email,k.slika,k.aktivan,t.naziv as \"TipKorisnika\"
					from korisnik k inner join tip_korisnika t on k.tip_id = t.tip_id";
			$izvrsi=izvrsiBP($sql);
			$broj_redaka = mysqli_num_rows($izvrsi);
			$broj_str = ceil($broj_redaka / $vel_str);  
			?>			
			<table id="dataview">
			<thead>
			  <tr>
				<th>Ime i prezime</th>
				<th>Korisničko ime</th>
				<th>E-mail</th>
				<th>Tip</th>
				<th>Slika</th>
				<th>Akcija</th>
			  </tr>
			</thead>
			<tbody>
			<?php			
			$sql.=" order by k.korisnik_id asc limit ".$vel_str;
			
			if(isset($_GET['str'])){
			$sql = $sql . " offset " . (($_GET['str'] - 1) * $vel_str);
			$aktivna = $_GET['str'];
			}
			else
			{
				$aktivna = 1;
			}
			$izvrsi=izvrsiBP($sql);
			$kol=7;
			
			$korupd=0;
			if(isset($_GET["korid"])){
				$korupd=$_GET["korid"];
			}
			$klasa="";
			if(mysqli_num_rows($izvrsi)>0){
			while(list($korisnikid, $tip, $korime,$ime,$prezime,$email, $slika,$aktivan,$korisniknaziv)=mysqli_fetch_array($izvrsi)){
			
			if($korupd==$korisnikid){
				if($aktivan==1){
					$klasa="aktiviran";
				}
				else
				{
					$klasa="suspendiran";
				}
			}
				
			$uredi="<a href=\"korisnik.php?korisnik=$korisnikid\">Uredi</a>";
			if($aktivan==0){
				$aktiviraj="<a href=\"korisnik.php?aktiviraj=$korisnikid&str=$aktivna\">Aktiviraj</a>";
			}
			else
			{
				$aktiviraj="<a href=\"korisnik.php?deaktiviraj=$korisnikid&str=$aktivna\">Suspendiraj</a>";
			}
			
			?>
				  <tr class="<?php echo $klasa; ?>">
					<td><?php echo $ime." ".$prezime; ?></td>
					<td><?php echo $korime; ?></td>
					<td><?php echo $email; ?></td>
					<td><?php echo $korisniknaziv; ?></td>
					<td><img src="<?php echo $slika; ?>" width="100" height="90"></td>			
					<td><?php 
					if($tip!=0){
						echo $uredi." | ".$aktiviraj;
					}
					 				
					?></td>				
				  </tr>
			<?php
			$klasa="";
				}
			}
			else
				{
			?>
				  <tr>
					<td colspan="7">Nema evidentiranih korisnika!</td>
				  </tr>
			<?php
				}
			 echo "<tr>";
			 echo "<td colspan=\"$kol\" class=\"last\">";
			 echo "Stranice: ";
			 for($str=1;$str<=$broj_str;$str++){
				 echo " <a href=\"korisnici.php?str=$str\">";
				 if($aktivna==$str){
					 echo "<mark>$str</mark>";
				 }
				 else
				 {
					echo "$str"; 
				 }				 
				 echo "</a>";
			 }
			 echo "</td>";
			 echo "</tr>";
			?>
			</tbody>
			</table>
			
			<?php
			if($aktivni_korisnik_tip==0){
				echo "<p><a href=\"korisnik.php?novi=1\">Dodavanje novog korisnika</a></p>";
			}
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>