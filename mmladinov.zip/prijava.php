<?php
include("spojnabazu.php");

if(session_status()==PHP_SESSION_NONE){
session_start();	
}

	if(isset($_POST['korisnicko_ime'])){

		$korisnik=$_POST['korisnicko_ime']; 
		$sifra=$_POST['lozinka'];

		if(!empty($korisnik) && !empty($sifra)){

			
			$sql="SELECT 
			k.korisnik_id,
			k.tip_id,
			k.korisnicko_ime,
			k.ime,
			k.prezime,
			k.slika,
			k.aktivan,
			tk.naziv
			FROM korisnik k inner join tip_korisnika tk on 
			k.tip_id = tk.tip_id
			WHERE k.korisnicko_ime='$korisnik' AND k.lozinka='$sifra'";
			$spoj = izvrsiBP($sql);
			if(mysqli_num_rows($spoj)>0){
				
				list($idkor,$idtip,$korime,$ime,$prezime,$slika,$aktivan,$nazivtip)=mysqli_fetch_array($spoj);
				
				if($aktivan==0){
					$_SESSION["errorinfo"]="Vaš račun nije još aktiviran od strane administratora!";
					header("Location: index.php");
					exit();
				}
				
				$_SESSION['aktivni_korisnik']=$korime;
				$_SESSION['aktivni_korisnik_ime']=$ime." ".$prezime;
				$_SESSION["aktivni_korisnik_id"]=$idkor;
				$_SESSION['aktivni_korisnik_tip']=$idtip;
				$_SESSION['aktivni_korisnik_slika']=$slika;
				$_SESSION['aktivni_korisnik_tipime']=$nazivtip;				
			}
			else
			{
				$_SESSION["errorinfo"]="Neispravni podaci za prijavu!";
				header("Location: index.php");
				exit();
			}

		}
		else
		{
			$_SESSION["errorinfo"]="Niste upisali nikakve podatke!";
		}
		
		header("Location:index.php");
	} 
?>