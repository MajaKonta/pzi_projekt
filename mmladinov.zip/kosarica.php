<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
      <h3>Popis svih moijh proizvoda u košarici:</h3>
      <?php
	  if(!isset($_SESSION["proizvodi"])){
		  $_SESSION["proizvodi"]=array();
	  }
	  
			if($_SERVER["QUERY_STRING"]==""){
				  if(isset($_SESSION["proizvodi"]) && count($_SESSION["proizvodi"])>0){
					echo "<ul>";
						foreach($_SESSION["proizvodi"] as $k=>$v){
							$sql="select pr.proizvod_id, pr.naziv, pr.cijena, kt.naziv from proizvod pr inner join kategorija kt on pr.kategorija_id = kt.kategorija_id 
							where pr.proizvod_id = ".$v;
							$izvrsi=izvrsiBP($sql);							
							list($proizvodid,$naziv,$cijena,$kategorija)=mysqli_fetch_row($izvrsi);
							echo "<li><strong>Kategorija:</strong> ".$kategorija.", <strong>ID proizvod:</strong> ".$proizvodid.", <strong>Naziv:</strong> ".$naziv.", <strong>Cijena:</strong> ".$cijena;
							echo " => <a href='kosarica.php?makniproizvod=$proizvodid&kos=1'>Makni proizvod</a> | <a href='narudzba.php?naruciproizvod=$proizvodid'>Naruči</a></li>";
						}
					echo "</ul>";
					
					echo "<h3 style='clear:both'><a href='sviproizvodigalerija.php'>Svi ostali proizvodi</a></h3>";
				  }
				  else
				  {
					  echo "<h3>Nemate proizvoda u košarici</h3>";
				  }
			}
	  
	
			if(isset($_GET["dodajproizvod"])){
				$idproizvod=$_GET["dodajproizvod"];
				$_SESSION["proizvodi"][$idproizvod]=$idproizvod;
				header("Location: sviproizvodigalerija.php");
			}
			
			
			if(isset($_GET["makniproizvod"])){
				$idproizvod=$_GET["makniproizvod"];
				unset($_SESSION["proizvodi"][$idproizvod]);
				if(isset($_GET["kos"])){
					header("Location: kosarica.php");
				}
				else
				{
					header("Location: sviproizvodigalerija.php");
				}
				
			}
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>