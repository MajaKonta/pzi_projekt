<?php require("zaglavlje.php"); ?>
<div id="content">
  <div id="main">
    <div id="example">
	<h3>Popis narudžbi iz kategorija koje moderiram:</h3>
      <?php	
	
		$sql = "SELECT
nar.narudzba_id,
pr.proizvod_id,
pr.naziv,
kt.kategorija_id,
kt.naziv,
kt.limit,
nar.kolicina,
pr.cijena,
(nar.kolicina*pr.cijena) AS 'Ukupno',
pr.slika,
nar.blokirana,
nar.prihvacena,
nar.datum_kreiranja,
kor.ime,
kor.prezime
FROM narudzba nar
INNER JOIN proizvod pr
ON nar.proizvod_id = pr.proizvod_id
INNER JOIN kategorija kt
on kt.kategorija_id = pr.kategorija_id 
INNER JOIN korisnik kor
on nar.korisnik_id = kor.korisnik_id";
if($aktivni_korisnik_tip==1){
$sql.=" WHERE kt.moderator_id = ".$aktivni_korisnik_id." order by kt.naziv desc";		
} 
	
	$izvrsi=izvrsiBP($sql);	 
	$broj_redaka = mysqli_num_rows($izvrsi);
	$broj_str = ceil($broj_redaka / $vel_str);	
	$sql .= " limit ".$vel_str;		
	
	if (isset($_GET['str'])){
		$sql = $sql . " OFFSET " . (($_GET['str'] - 1) * $vel_str);
		$aktivna = $_GET['str'];
	} else {
		$aktivna = 1;
	}

	$izvrsi=izvrsiBP($sql);
	$kol=11;
	echo "<table id = \"dataview\">";
	echo "<thead>";
	echo "<tr>";
	echo "<th>ID narudžbe</th>";
	echo "<th>Proizvod</th>";
	echo "<th>Kategorija</th>";
	echo "<th>Preostalo limita</th>";
	echo "<th>Količina</th>";
	echo "<th>Cijena</th>";
	echo "<th>Datum kreiranja</th>";
	echo "<th>Naručitelj</th>";
	echo "<th>Blokirana</th>";
	echo "<th>Prihvaćena</th>";
	echo "<th>Mogućnosti</th>";
	echo "</tr>";
	echo "</thead>";
	
	echo "<tbody>";
	if(mysqli_num_rows($izvrsi)>0){
		while(list($narudzbaid,$proizvodid, $nazivproizvod, $kategorijaid, $nazivkategorija, $limit, $kolicina,$cijena,$ukupno,$slika,$blokirana,$prihvacena,$datumkreiranja,$korime,$korprezime)=mysqli_fetch_row($izvrsi)){
			$prihvatinar="<a href='narudzba.php?prihvatinarudzbu=$narudzbaid&str=$aktivna'>Prihvati narudžbu</a>";
			$datumkreiranja=date("d.m.Y H:i:s",strtotime($datumkreiranja));
			if($blokirana==1){
				$blokirana="da";
			}
			else
			{
				$blokirana="ne";
			}
			
			if($prihvacena==1){
				$prihvacena="da";
			}
			else
			{
				$prihvacena="ne";
			}
			echo "<tr>";
			echo "<td>$narudzbaid</td>";
			echo "<td>$nazivproizvod</td>";
			echo "<td>$nazivkategorija</td>";
			echo "<td>".PreostaloLimitaUKategoriji($kategorijaid)."</td>";
			echo "<td class='number'>$kolicina</td>";
			echo "<td>$cijena</td>";
			echo "<td>$datumkreiranja</td>";
			echo "<td>$korime $korprezime</td>";
			echo "<td>$blokirana</td>";
			echo "<td>$prihvacena</td>";
			echo "<td>";
			
			if($prihvacena=="ne"){
				if($blokirana=="ne"){
					echo $prihvatinar;
				}
			    else
				{
					echo "Prekoračen limit - odobrava admin";
				}
			}
			else
			{
				echo "";
			}

			echo "</td>";
		echo "</tr>";
		}
	}
	else
	{
		echo "<tr><td colspan='$kol'>Nemate narudžbi</tr>";
	}
   echo "<tr>";
			echo " <td colspan='$kol' class='last'>";
			 echo "Stranice: ";
			 for($str=1;$str<=$broj_str;$str++){
				 echo " <a href=\"moderatornarudzbe.php?str=$str\">";
				 if($aktivna==$str){
					 echo "<mark>$str</mark>";
				 }
				 else
				 {
					echo "$str"; 
				 }				 
				 echo "</a>";
			 }
			echo "</td>";
			echo "</tr>";
   echo "</tbody>";
   echo "</table>";			
	
	echo "<p><a href='korisniknarudzbe.php'>Moje vlastite narudžbe</a></p>";	
	?>

    </div>
    	<?php 
	 Natrag();
	?>
  </div>

  <div id="sidebar">
<?php 
include("obrazacprijava.php"); 
include("topproizvodi.php"); 

?>
  </div>
</div>
<?php require("podnozje.php"); ?>